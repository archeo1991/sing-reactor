(() => {
  'use strict';

  globalThis.BLSConfig = Object.freeze({
    API_BASE: "https://singreactor.archeo.cn"
  });
})();
